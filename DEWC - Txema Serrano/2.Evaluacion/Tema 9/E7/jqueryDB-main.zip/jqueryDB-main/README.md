# jqueryDB

CRUD database en jquery

url: http://www.txemaserrano.com/proyectos/jquerydb

